# Youtube Live Extension

YouTube Live is an extension that brings your favorite YouTube channels into a clean, modern, YouTube-styled interface.

## Official Extension

[<img src="https://fonts.gstatic.com/s/i/productlogos/chrome_store/v7/192px.svg" width="15"/> Youtube Live on Chrome Store](https://chrome.google.com/webstore/detail/youtube-live/emmdnfhlabapoeelnkhkekohllbncdfk)
